
#include "test_common.h"
#include "blood_inventory.h"

static BmsBloodInventory_t rec(uint32_t id,BmsBloodGroup_t g,uint32_t u,uint16_t y)
{
    BmsBloodInventory_t r;
    memset(&r,0,sizeof r);
    r.bloodId=id; r.bloodGroup=g; r.units=u;
    r.collectionDate=(BmsDate_t){2026,1,1};
    r.expiryDate=(BmsDate_t){y,12,31};
    r.isAvailable=true;
    return r;
}

static BmsStatus_t countv(const BmsBloodInventory_t*r,void*c)
{
    (void)r; (*(uint32_t*)c)++; return BMS_STATUS_OK;
}

static void test_stock(void)
{
    BmsInventoryContext_t c;
    BmsBloodInventory_t a=rec(1,BMS_BLOOD_GROUP_A_POSITIVE,5,2027),out;
    uint32_t units=0;

    ASSERT_OK(BloodInventoryInitialize(&c));
    ASSERT_OK(BloodInventoryAddStock(&c,&a));
    ASSERT_STATUS(BMS_STATUS_ALREADY_EXISTS,BloodInventoryAddStock(&c,&a));
    ASSERT_OK(BloodInventorySearchById(&c,1,&out));
    ASSERT_OK(BloodInventoryUpdateStock(&c,1,8));
    ASSERT_OK(BloodInventoryRemoveStock(&c,1,3));
    ASSERT_OK(BloodInventoryGetAvailableUnits(&c,BMS_BLOOD_GROUP_A_POSITIVE,&units));
    CU_ASSERT_EQUAL(units,5U);
    ASSERT_STATUS(BMS_STATUS_INSUFFICIENT_STOCK,BloodInventoryRemoveStock(&c,1,99));
    BloodInventoryDeinitialize(&c);
}

static void test_expiry_low_stock(void)
{
    BmsInventoryContext_t c;
    BmsBloodInventory_t a=rec(1,BMS_BLOOD_GROUP_O_NEGATIVE,2,2025);
    BmsBloodInventory_t b=rec(2,BMS_BLOOD_GROUP_B_POSITIVE,3,2027);
    BmsDate_t now={2026,8,4};
    uint32_t removed=0,count=0;

    ASSERT_OK(BloodInventoryInitialize(&c));
    ASSERT_OK(BloodInventoryAddStock(&c,&a));
    ASSERT_OK(BloodInventoryAddStock(&c,&b));
    ASSERT_OK(BloodInventoryRemoveExpired(&c,&now,&removed));
    CU_ASSERT_EQUAL(removed,1U);
    ASSERT_OK(BloodInventoryDetectLowStock(&c,5U,countv,&count));
    CU_ASSERT_EQUAL(count,1U);
    BloodInventoryDeinitialize(&c);
}

static void test_inventory_missing_cases(void)
{
    BmsInventoryContext_t c;
    BmsBloodInventory_t out;
    uint32_t units=0;

    ASSERT_OK(BloodInventoryInitialize(&c));
    CU_ASSERT_NOT_EQUAL(BloodInventorySearchById(&c,999U,&out),BMS_STATUS_OK);
    CU_ASSERT_NOT_EQUAL(BloodInventoryRemoveStock(&c,999U,1U),BMS_STATUS_OK);
    ASSERT_OK(BloodInventoryGetAvailableUnits(&c,BMS_BLOOD_GROUP_A_POSITIVE,&units));
    CU_ASSERT_EQUAL(units,0U);
    BloodInventoryDeinitialize(&c);
}

void RegisterInventoryTests(void)
{
    CU_pSuite s=CU_add_suite("Blood Inventory",NULL,NULL);
    CU_add_test(s,"add update remove availability",test_stock);
    CU_add_test(s,"expiry and low stock",test_expiry_low_stock);
    CU_add_test(s,"missing records and empty inventory",test_inventory_missing_cases);
}
