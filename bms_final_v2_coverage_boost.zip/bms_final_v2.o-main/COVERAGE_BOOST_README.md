# Coverage Boost Package

## Scope

This coverage update does **not modify any production BMS `.c` or `.h` files**.

The coverage improvement is test-side only:

- `test_coverage_boost.c` — additional CUnit edge/error/persistence tests
- `test_runner.c` — registers the additional coverage suite
- `build_cunit.sh` — builds the real CUnit runner and all test files
- `run_coverage.sh` — builds with GCOV instrumentation and generates the coverage report

## What the additional tests target

The coverage suite adds tests for:

- NULL/invalid arguments
- empty and missing persistence files
- save/load paths
- corrupt persistence headers
- duplicate records
- not-found records
- empty queues and callback failures
- inventory expiry and low-stock paths
- request priority and insufficient-stock retry
- notification sender failures and placeholder senders
- emergency-alert resolution by request
- authentication lock/unlock, status, recovery and password failures
- utility input, parsing, date and boundary paths
- graph error/traversal paths
- multithreaded inventory monitoring start/stop and periodic checks
- report argument/error paths
- donation-camp persistence and visitor errors

## Run

First make sure the production `.c/.h` versions in your working copy match the versions used by the existing CUnit tests.

Then:

```bash
chmod +x build_cunit.sh run_coverage.sh
./build_cunit.sh
./run_coverage.sh
```

The detailed GCOV files are written to:

```text
analysis/coverage/
```

The summary is:

```text
coverage_summary.txt
```

## Important

100% line coverage cannot be guaranteed merely by adding normal unit tests. Some defensive branches, especially deliberate `malloc/calloc`, `fopen`, `pthread_create`, and system-call failure paths, require fault injection or controlled failure wrappers.

The goal of this package is therefore to drive coverage as high as the public APIs can realistically exercise without changing production implementation code.

Production `.c` and `.h` files must remain untouched.
