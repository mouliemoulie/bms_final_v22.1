#include "test_common.h"

#include "authentication.h"
#include "blood_inventory.h"
#include "blood_request_management.h"
#include "common_validation.h"
#include "donation_camp_management.h"
#include "donation_management.h"
#include "donor_management.h"
#include "emergency_alert_management.h"
#include "file_management.h"
#include "file_names.h"
#include "graph_management.h"
#include "hospital_management.h"
#include "logging.h"
#include "notification_management.h"
#include "multithreading.h"
#include "queue_management.h"
#include "report_management.h"
#include "utility.h"

#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

static BmsDonor_t boost_donor(uint32_t id, const char *name,
                              BmsBloodGroup_t group)
{
    BmsDonor_t d;
    (void)memset(&d, 0, sizeof(d));
    d.donorId = id;
    (void)snprintf(d.name, sizeof(d.name), "%s", name);
    d.age = 30U;
    d.weightKg = 60U;
    d.bloodGroup = group;
    (void)snprintf(d.phone, sizeof(d.phone), "9876543210");
    (void)snprintf(d.email, sizeof(d.email), "d%u@example.com", id);
    (void)snprintf(d.address, sizeof(d.address), "Chennai");
    d.lastDonationDate = (BmsDate_t){2026U, 1U, 1U};
    d.isEligible = true;
    d.isActive = true;
    return d;
}

static BmsHospital_t boost_hospital(uint32_t id, const char *name)
{
    BmsHospital_t h;
    (void)memset(&h, 0, sizeof(h));
    h.hospitalId = id;
    (void)snprintf(h.name, sizeof(h.name), "%s", name);
    (void)snprintf(h.location, sizeof(h.location), "Chennai");
    (void)snprintf(h.address, sizeof(h.address), "Main Road");
    (void)snprintf(h.contactNumber, sizeof(h.contactNumber), "9876543210");
    (void)snprintf(h.email, sizeof(h.email), "h%u@example.com", id);
    h.isActive = true;
    return h;
}

static BmsBloodInventory_t boost_stock(uint32_t id, BmsBloodGroup_t group,
                                       uint32_t units, BmsDate_t expiry)
{
    BmsBloodInventory_t r;
    (void)memset(&r, 0, sizeof(r));
    r.bloodId = id;
    r.bloodGroup = group;
    r.units = units;
    r.collectionDate = (BmsDate_t){2026U, 1U, 1U};
    r.expiryDate = expiry;
    r.isAvailable = units > 0U;
    return r;
}

static BmsDonation_t boost_donation(uint32_t id, uint32_t donorId)
{
    BmsDonation_t d;
    (void)memset(&d, 0, sizeof(d));
    d.donationId = id;
    d.donorId = donorId;
    d.bloodGroup = BMS_BLOOD_GROUP_A_POSITIVE;
    d.units = 2U;
    d.donationDate = (BmsDate_t){2026U, 8U, 1U};
    d.collectionHospitalId = 1U;
    return d;
}

static BmsBloodRequest_t boost_request(uint32_t id, BmsPriority_t priority,
                                       uint32_t units)
{
    BmsBloodRequest_t r;
    (void)memset(&r, 0, sizeof(r));
    r.requestId = id;
    r.requesterHospitalId = 1U;
    r.requesterId = 1U;
    r.bloodGroup = BMS_BLOOD_GROUP_A_POSITIVE;
    r.requestedUnits = units;
    r.priority = priority;
    r.status = BMS_REQUEST_STATUS_PENDING;
    r.requestDate = (BmsDate_t){2026U, 8U, 1U};
    r.requiredByDate = (BmsDate_t){2026U, 8U, 10U};
    return r;
}

static BmsNotification_t boost_notification(uint32_t id)
{
    BmsNotification_t n;
    (void)memset(&n, 0, sizeof(n));
    n.notificationId = id;
    n.recipientUserId = 1U;
    n.recipientHospitalId = 1U;
    n.channel = BMS_NOTIFICATION_CHANNEL_CONSOLE;
    n.priority = BMS_PRIORITY_HIGH;
    (void)snprintf(n.message, sizeof(n.message), "Coverage notification");
    return n;
}

static BmsEmergencyAlert_t boost_alert(uint32_t id, uint32_t requestId)
{
    BmsEmergencyAlert_t a;
    (void)memset(&a, 0, sizeof(a));
    a.alertId = id;
    a.requestId = requestId;
    a.sourceHospitalId = 1U;
    a.createdByUserId = 1U;
    a.bloodGroup = BMS_BLOOD_GROUP_O_NEGATIVE;
    a.requiredUnits = 4U;
    a.priority = BMS_PRIORITY_EMERGENCY;
    (void)snprintf(a.message, sizeof(a.message), "Urgent blood required");
    return a;
}

static BmsDonationCamp_t boost_camp(uint32_t id)
{
    BmsDonationCamp_t c;
    (void)memset(&c, 0, sizeof(c));
    c.campId = id;
    (void)snprintf(c.name, sizeof(c.name), "Coverage Camp");
    c.date = (BmsDate_t){2026U, 8U, 20U};
    (void)snprintf(c.time, sizeof(c.time), "09:00");
    (void)snprintf(c.venue, sizeof(c.venue), "Community Hall");
    (void)snprintf(c.city, sizeof(c.city), "Chennai");
    (void)snprintf(c.organizer, sizeof(c.organizer), "Blood Bank");
    (void)snprintf(c.contactNumber, sizeof(c.contactNumber), "9876543210");
    (void)snprintf(c.email, sizeof(c.email), "camp@example.com");
    c.isActive = true;
    return c;
}

static BmsStatus_t boost_count_visitor(const void *record, uint32_t index,
                                       void *context)
{
    (void)record;
    (void)index;
    (*(uint32_t *)context)++;
    return BMS_STATUS_OK;
}

static BmsStatus_t boost_fail_visitor(const void *record, uint32_t index,
                                      void *context)
{
    (void)record;
    (void)index;
    (void)context;
    return BMS_STATUS_INTERNAL_ERROR;
}

static BmsStatus_t boost_donor_visitor(const BmsDonor_t *record, void *context)
{
    (void)record;
    (*(uint32_t *)context)++;
    return BMS_STATUS_OK;
}

static BmsStatus_t boost_donor_fail(const BmsDonor_t *record, void *context)
{
    (void)record;
    (void)context;
    return BMS_STATUS_INTERNAL_ERROR;
}

static BmsStatus_t boost_inventory_visitor(const BmsBloodInventory_t *record,
                                           void *context)
{
    (void)record;
    (*(uint32_t *)context)++;
    return BMS_STATUS_OK;
}

static BmsStatus_t boost_inventory_fail(const BmsBloodInventory_t *record,
                                        void *context)
{
    (void)record;
    (void)context;
    return BMS_STATUS_INTERNAL_ERROR;
}

static BmsStatus_t boost_request_visitor(const BmsBloodRequest_t *record,
                                         void *context)
{
    (void)record;
    (*(uint32_t *)context)++;
    return BMS_STATUS_OK;
}

static BmsStatus_t boost_request_fail(const BmsBloodRequest_t *record,
                                      void *context)
{
    (void)record;
    (void)context;
    return BMS_STATUS_INTERNAL_ERROR;
}

static BmsStatus_t boost_donation_visitor(const BmsDonation_t *record,
                                          void *context)
{
    (void)record;
    (*(uint32_t *)context)++;
    return BMS_STATUS_OK;
}

static BmsStatus_t boost_donation_fail(const BmsDonation_t *record,
                                       void *context)
{
    (void)record;
    (void)context;
    return BMS_STATUS_INTERNAL_ERROR;
}

static BmsStatus_t boost_notification_sender(const BmsNotification_t *record,
                                             void *context)
{
    (void)record;
    (*(uint32_t *)context)++;
    return BMS_STATUS_OK;
}

static BmsStatus_t boost_notification_fail(const BmsNotification_t *record,
                                           void *context)
{
    (void)record;
    (void)context;
    return BMS_STATUS_INTERNAL_ERROR;
}

static BmsStatus_t boost_hospital_visitor(const BmsHospital_t *record,
                                          void *context)
{
    (void)record;
    (*(uint32_t *)context)++;
    return BMS_STATUS_OK;
}

static BmsStatus_t boost_hospital_fail(const BmsHospital_t *record,
                                       void *context)
{
    (void)record;
    (void)context;
    return BMS_STATUS_INTERNAL_ERROR;
}

static BmsStatus_t boost_request_graph_visitor(const BmsHospital_t *record,
                                               void *context)
{
    (void)record;
    (*(uint32_t *)context)++;
    return BMS_STATUS_OK;
}

static BmsStatus_t boost_graph_fail(const BmsHospital_t *record, void *context)
{
    (void)record;
    (void)context;
    return BMS_STATUS_INTERNAL_ERROR;
}

static BmsStatus_t boost_camp_visitor(const BmsDonationCamp_t *record,
                                      void *context)
{
    (void)record;
    (*(uint32_t *)context)++;
    return BMS_STATUS_OK;
}

static BmsStatus_t boost_camp_fail(const BmsDonationCamp_t *record,
                                   void *context)
{
    (void)record;
    (void)context;
    return BMS_STATUS_INTERNAL_ERROR;
}

static void test_boost_utility(void)
{
    char dst[8];
    char text[32] = "  hello  ";
    uint32_t value = 0U;
    BmsBloodGroup_t group = BMS_BLOOD_GROUP_INVALID;
    BmsDate_t date = {2024U, 12U, 31U};
    BmsDate_t result;

    ASSERT_OK(UtilitySafeStringCopy(dst, sizeof(dst), "hello"));
    ASSERT_STATUS(BMS_STATUS_BUFFER_TOO_SMALL,
                  UtilitySafeStringCopy(dst, sizeof(dst), "12345678"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  UtilitySafeStringCopy(NULL, sizeof(dst), "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  UtilitySafeStringCopy(dst, 0U, "x"));

    UtilityTrimWhitespace(text);
    CU_ASSERT_STRING_EQUAL(text, "hello");
    UtilityTrimWhitespace(NULL);

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, UtilityParseUint32(NULL, &value));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, UtilityParseUint32("1", NULL));

    CU_ASSERT_EQUAL(UtilityDaysInMonth(2024U, 0U), 0U);
    CU_ASSERT_EQUAL(UtilityDaysInMonth(2024U, 13U), 0U);
    CU_ASSERT_EQUAL(UtilityDaysInMonth(2024U, 2U), 29U);
    CU_ASSERT_EQUAL(UtilityDaysInMonth(2023U, 2U), 28U);

    CU_ASSERT_EQUAL(UtilityCompareDates(NULL, &date), 0);
    CU_ASSERT_EQUAL(UtilityCompareDates(&date, NULL), 0);
    CU_ASSERT_TRUE(UtilityCompareDates(&date, &(BmsDate_t){2024U, 1U, 1U}) > 0);

    CU_ASSERT_EQUAL(UtilityCalculateChecksum(NULL, 3U), 0U);
    CU_ASSERT_NOT_EQUAL(UtilityCalculateChecksum("a", 1U),
                       UtilityCalculateChecksum("b", 1U));

    CU_ASSERT_STRING_EQUAL(UtilityStatusToString(BMS_STATUS_OK), "OK");
    CU_ASSERT_STRING_EQUAL(UtilityStatusToString((BmsStatus_t)999), "Unknown");
    CU_ASSERT_STRING_EQUAL(UtilityBloodGroupToString(BMS_BLOOD_GROUP_INVALID),
                           "INVALID");
    CU_ASSERT_STRING_EQUAL(UtilityBloodGroupToString((BmsBloodGroup_t)999),
                           "INVALID");

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  UtilityStringToBloodGroup(NULL, &group));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  UtilityStringToBloodGroup("A+", NULL));
    ASSERT_OK(UtilityStringToBloodGroup("A+", &group));
    ASSERT_STATUS(BMS_STATUS_INVALID_DATA,
                  UtilityStringToBloodGroup("not-a-group", &group));

    {
        int savedStdin = dup(STDIN_FILENO);
        int pipeFd[2];
        char input[32];
        uint32_t parsed = 0U;

        CU_ASSERT_EQUAL(pipe(pipeFd), 0);
        if (pipeFd[0] >= 0)
        {
            (void)write(pipeFd[1], "123\n", 4U);
            (void)close(pipeFd[1]);
            (void)dup2(pipeFd[0], STDIN_FILENO);
            (void)close(pipeFd[0]);
            clearerr(stdin);
            ASSERT_OK(UtilityReadLine(input, sizeof(input)));
            CU_ASSERT_STRING_EQUAL(input, "123");
            (void)dup2(savedStdin, STDIN_FILENO);
        }

        CU_ASSERT_EQUAL(pipe(pipeFd), 0);
        if (pipeFd[0] >= 0)
        {
            (void)write(pipeFd[1], "456", 3U);
            (void)close(pipeFd[1]);
            (void)dup2(pipeFd[0], STDIN_FILENO);
            (void)close(pipeFd[0]);
            clearerr(stdin);
            ASSERT_OK(UtilityReadLine(input, sizeof(input)));
            CU_ASSERT_STRING_EQUAL(input, "456");
            (void)dup2(savedStdin, STDIN_FILENO);
        }

        CU_ASSERT_EQUAL(pipe(pipeFd), 0);
        if (pipeFd[0] >= 0)
        {
            (void)write(pipeFd[1], "789\n", 4U);
            (void)close(pipeFd[1]);
            (void)dup2(pipeFd[0], STDIN_FILENO);
            (void)close(pipeFd[0]);
            clearerr(stdin);
            ASSERT_OK(UtilityReadUint32(NULL, &parsed));
            CU_ASSERT_EQUAL(parsed, 789U);
            (void)dup2(savedStdin, STDIN_FILENO);
        }

        close(savedStdin);
    }
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, UtilityReadLine(NULL, sizeof(dst)));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, UtilityReadLine(dst, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, UtilityReadUint32(NULL, NULL));

    UtilitySecureZero(NULL, 5U);

    CU_ASSERT_TRUE(ValidateDateValue(&(BmsDate_t){2024U, 2U, 29U}));
    CU_ASSERT_FALSE(ValidateDateValue(NULL));
    CU_ASSERT_FALSE(ValidateDateValue(&(BmsDate_t){1899U, 1U, 1U}));
    CU_ASSERT_FALSE(ValidateDateValue(&(BmsDate_t){2024U, 13U, 1U}));
    CU_ASSERT_FALSE(ValidateDateValue(&(BmsDate_t){2024U, 2U, 30U}));

    CU_ASSERT_FALSE(ValidateName("A1"));
    CU_ASSERT_TRUE(ValidateName("A-B.C"));
    CU_ASSERT_FALSE(ValidateUsername("ab"));
    CU_ASSERT_TRUE(ValidateUsername("user_01.test"));
    CU_ASSERT_FALSE(ValidateEmail("a b@test.com"));
    CU_ASSERT_FALSE(ValidateEmail("a@@test.com"));
    CU_ASSERT_FALSE(ValidateEmail("a@.com"));
    CU_ASSERT_FALSE(ValidateEmail("a@test."));
    CU_ASSERT_FALSE(ValidateEmail("a!@test.com"));
    CU_ASSERT_FALSE(ValidateAddress("abc"));
    CU_ASSERT_TRUE(ValidateLocation("IN"));
    CU_ASSERT_FALSE(ValidateLocation("I"));
    CU_ASSERT_TRUE(ValidateContactNumber("9876543210"));

    CU_ASSERT_TRUE(ValidatePositiveNumber(1U));
    CU_ASSERT_FALSE(ValidatePositiveNumber(0U));
    CU_ASSERT_TRUE(ValidateNonZero(1U));
    CU_ASSERT_FALSE(ValidateNonZero(0U));
    CU_ASSERT_FALSE(ValidateBloodId(0U));
    CU_ASSERT_TRUE(ValidateBloodId(1U));
    CU_ASSERT_FALSE(ValidateDonationId(0U));
    CU_ASSERT_TRUE(ValidateDonationId(1U));
    CU_ASSERT_TRUE(ValidateUserRole(1U));
    CU_ASSERT_FALSE(ValidateUserRole(0U));
    CU_ASSERT_TRUE(ValidateBloodGroupValue(BMS_BLOOD_GROUP_A1_POSITIVE));
    CU_ASSERT_FALSE(ValidateBloodGroupValue(BMS_BLOOD_GROUP_COUNT));

    CU_ASSERT_TRUE(ValidateBloodGroup("A1+"));
    CU_ASSERT_TRUE(ValidateBloodGroup("ABRHD+"));
    CU_ASSERT_TRUE(ValidateBloodGroup("o negative"));
    CU_ASSERT_FALSE(ValidateBloodGroup(NULL));
    ASSERT_STATUS(BMS_STATUS_OK, BmsDateAddDays(&date, 1U, &result));
    CU_ASSERT_EQUAL(result.year, 2025U);
    CU_ASSERT_EQUAL(result.month, 1U);
    CU_ASSERT_EQUAL(result.day, 1U);
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, BmsDateAddDays(NULL, 1U, &result));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, BmsDateAddDays(&date, 1U, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_DATA,
                  BmsDateAddDays(&(BmsDate_t){1800U, 1U, 1U}, 1U, &result));
}

static void test_boost_file_management(void)
{
    ASSERT_OK(FileManagementInitialize());
    const char *path = "coverage_corrupt.dat";
    uint32_t value = 42U;
    uint32_t out = 0U;
    uint32_t count = 0U;
    bool exists = false;
    uint32_t visited = 0U;
    FILE *f;

    (void)FileManagementDeleteFile(path);
    ASSERT_STATUS(BMS_STATUS_FILE_NOT_FOUND,
                  FileManagementReadRecords(path, &out, 1U, &count,
                                             sizeof(value)));
    ASSERT_STATUS(BMS_STATUS_FILE_NOT_FOUND,
                  FileManagementGetRecordCount(path, sizeof(value), &count));
    ASSERT_STATUS(BMS_STATUS_FILE_NOT_FOUND,
                  FileManagementVisitRecords(path, sizeof(value),
                                             boost_count_visitor, &visited));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  FileManagementReadRecords(NULL, &out, 1U, &count, sizeof(value)));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  FileManagementReadRecords(path, NULL, 1U, &count, sizeof(value)));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  FileManagementReadRecords(path, &out, 1U, NULL, sizeof(value)));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  FileManagementGetRecordCount(path, 0U, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  FileManagementVisitRecords(path, sizeof(value), NULL, &visited));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, FileManagementDeleteFile(NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  FileManagementFileExists(NULL, &exists));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  FileManagementFileExists(path, NULL));

    f = fopen(path, "wb");
    CU_ASSERT_PTR_NOT_NULL(f);
    if (f != NULL)
    {
        (void)fwrite("bad", 1U, 3U, f);
        (void)fclose(f);
    }
    ASSERT_STATUS(BMS_STATUS_READ_ERROR,
                  FileManagementGetRecordCount(path, sizeof(value), &count));

    ASSERT_OK(FileManagementWriteRecords(path, &value, 1U, sizeof(value)));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  FileManagementVisitRecords(path, sizeof(value),
                                             boost_fail_visitor, &visited));

    /* Replace the file header with an invalid magic value. */
    f = fopen(path, "r+b");
    CU_ASSERT_PTR_NOT_NULL(f);
    if (f != NULL)
    {
        BmsFileHeader_t header;
        (void)fread(&header, sizeof(header), 1U, f);
        header.magic = 0U;
        (void)fseek(f, 0L, SEEK_SET);
        (void)fwrite(&header, sizeof(header), 1U, f);
        (void)fclose(f);
    }
    ASSERT_STATUS(BMS_STATUS_FILE_CORRUPT,
                  FileManagementGetRecordCount(path, sizeof(value), &count));
    ASSERT_STATUS(BMS_STATUS_FILE_CORRUPT,
                  FileManagementReadRecords(path, &out, 1U, &count, sizeof(value)));

    (void)FileManagementDeleteFile(path);
}

static void test_boost_donor(void)
{
    BmsDonorContext_t c;
    BmsDonorContext_t loaded;
    BmsDonor_t d = boost_donor(701U, "Coverage Donor", BMS_BLOOD_GROUP_A_POSITIVE);
    BmsDonor_t bad = d;
    BmsDonor_t changed = d;
    BmsDonor_t out;
    uint32_t count = 0U;

    (void)remove(BMS_DONORS_FILE);
    ASSERT_OK(DonorManagementInitialize(&c));
    ASSERT_OK(DonorManagementLoad(&c));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, DonorManagementAdd(NULL, &d));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, DonorManagementAdd(&c, NULL));

    bad.donorId = 0U;
    ASSERT_STATUS(BMS_STATUS_INVALID_DATA, DonorManagementAdd(&c, &bad));

    ASSERT_OK(DonorManagementSave(&c));
    ASSERT_OK(DonorManagementLoad(&c));
    ASSERT_OK(DonorManagementAdd(&c, &d));
    ASSERT_OK(DonorManagementSave(&c));

    changed = d;
    changed.bloodGroup = BMS_BLOOD_GROUP_B_POSITIVE;
    ASSERT_STATUS(BMS_STATUS_INVALID_DATA, DonorManagementUpdate(&c, &changed));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, DonorManagementSearchById(NULL, 1U, &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, DonorManagementSearchById(&c, 1U, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, DonorManagementUpdate(NULL, &d));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, DonorManagementUpdate(&c, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, DonorManagementDelete(NULL, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonorManagementFindByBloodGroup(NULL, d.bloodGroup,
                                                 boost_donor_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonorManagementFindByBloodGroup(&c, d.bloodGroup, NULL, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonorManagementTraverse(NULL, boost_donor_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonorManagementTraverse(&c, NULL, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, DonorManagementSortByName(NULL));

    ASSERT_OK(DonorManagementFindByBloodGroup(&c, d.bloodGroup,
                                              boost_donor_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  DonorManagementFindByBloodGroup(&c, d.bloodGroup,
                                                 boost_donor_fail, NULL));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  DonorManagementTraverse(&c, boost_donor_fail, NULL));

    d.lastDonationDate = (BmsDate_t){2027U, 1U, 1U};
    ASSERT_OK(DonorManagementCheckEligibility(&d, &(BmsDate_t){2026U, 1U, 1U}));
    CU_ASSERT_FALSE(d.isEligible);
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonorManagementCheckEligibility(NULL, &(BmsDate_t){2026U, 1U, 1U}));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonorManagementCheckEligibility(&d, NULL));

    d = boost_donor(702U, "Another Donor", BMS_BLOOD_GROUP_O_POSITIVE);
    ASSERT_OK(DonorManagementAdd(&c, &d));
    ASSERT_OK(DonorManagementSortByName(&c));
    count = 0U;
    ASSERT_OK(DonorManagementTraverse(&c, boost_donor_visitor, &count));
    CU_ASSERT_EQUAL(count, 2U);

    DonorManagementDeinitialize(&c);

    ASSERT_OK(DonorManagementInitialize(&loaded));
    ASSERT_OK(DonorManagementLoad(&loaded));
    ASSERT_OK(DonorManagementSearchById(&loaded, 701U, &out));
    CU_ASSERT_STRING_EQUAL(out.name, "Coverage Donor");
    DonorManagementDeinitialize(&loaded);
}

static void test_boost_hospital(void)
{
    BmsHospitalContext_t c;
    BmsHospitalContext_t loaded;
    BmsHospital_t h = boost_hospital(801U, "Coverage Hospital");
    BmsHospital_t out;
    uint32_t count = 0U;

    (void)remove(BMS_HOSPITALS_FILE);
    ASSERT_OK(HospitalManagementInitialize(&c));
    ASSERT_OK(HospitalManagementLoad(&c));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, HospitalManagementAdd(NULL, &h));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, HospitalManagementAdd(&c, NULL));
    ASSERT_OK(HospitalManagementSave(&c));
    ASSERT_OK(HospitalManagementLoad(&c));
    ASSERT_OK(HospitalManagementAdd(&c, &h));
    ASSERT_STATUS(BMS_STATUS_ALREADY_EXISTS, HospitalManagementAdd(&c, &h));
    ASSERT_OK(HospitalManagementSave(&c));

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  HospitalManagementSearchById(NULL, 1U, &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  HospitalManagementSearchById(&c, 1U, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, HospitalManagementUpdate(NULL, &h));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, HospitalManagementUpdate(&c, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, HospitalManagementDelete(NULL, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  HospitalManagementTraverse(NULL, boost_hospital_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  HospitalManagementTraverse(&c, NULL, &count));

    ASSERT_OK(HospitalManagementTraverse(&c, boost_hospital_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  HospitalManagementTraverse(&c, boost_hospital_fail, NULL));

    HospitalManagementDeinitialize(&c);
    ASSERT_OK(HospitalManagementInitialize(&loaded));
    ASSERT_OK(HospitalManagementLoad(&loaded));
    ASSERT_OK(HospitalManagementSearchById(&loaded, 801U, &out));
    HospitalManagementDeinitialize(&loaded);
}

static void test_boost_inventory(void)
{
    BmsInventoryContext_t c;
    BmsInventoryContext_t loaded;
    BmsBloodInventory_t a = boost_stock(901U, BMS_BLOOD_GROUP_A_POSITIVE, 3U,
                                        (BmsDate_t){2027U, 1U, 1U});
    BmsBloodInventory_t expired = boost_stock(902U, BMS_BLOOD_GROUP_A_POSITIVE, 2U,
                                              (BmsDate_t){2025U, 1U, 1U});
    BmsBloodInventory_t unavailable = boost_stock(903U, BMS_BLOOD_GROUP_A_POSITIVE, 5U,
                                                  (BmsDate_t){2027U, 1U, 1U});
    uint32_t count = 0U;
    uint32_t units = 0U;
    BmsBloodInventory_t out;

    unavailable.isAvailable = false;
    (void)remove(BMS_INVENTORY_FILE);

    ASSERT_OK(BloodInventoryInitialize(&c));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, BloodInventoryAddStock(NULL, &a));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, BloodInventoryAddStock(&c, NULL));
    ASSERT_OK(BloodInventoryAddStock(&c, &a));
    ASSERT_OK(BloodInventoryAddStock(&c, &expired));
    ASSERT_OK(BloodInventoryAddStock(&c, &unavailable));
    ASSERT_STATUS(BMS_STATUS_ALREADY_EXISTS, BloodInventoryAddStock(&c, &a));

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventoryUpdateStock(NULL, 1U, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventorySearchById(NULL, 1U, &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventorySearchById(&c, 1U, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventoryGetAvailableUnits(NULL, a.bloodGroup, &units));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventoryGetAvailableUnits(&c, a.bloodGroup, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventoryRemoveExpired(NULL, NULL, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventoryDetectLowStock(NULL, 5U, boost_inventory_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventoryDetectLowStock(&c, 5U, NULL, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventoryCountLowStock(NULL, 5U, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventoryCountLowStock(&c, 5U, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventoryTraverse(NULL, boost_inventory_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodInventoryTraverse(&c, NULL, &count));

    ASSERT_OK(BloodInventoryUpdateStock(&c, 901U, 0U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND, BloodInventoryUpdateStock(&c, 9999U, 1U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND, BloodInventoryRemoveStock(&c, 9999U, 1U));
    ASSERT_OK(BloodInventoryRemoveStock(&c, 901U, 0U));
    ASSERT_STATUS(BMS_STATUS_INSUFFICIENT_STOCK,
                  BloodInventoryRemoveStock(&c, 902U, 99U));

    ASSERT_OK(BloodInventoryGetAvailableUnits(&c, a.bloodGroup, &units));
    CU_ASSERT_EQUAL(units, 2U);

    ASSERT_OK(BloodInventoryCountLowStock(&c, 5U, &count));
    CU_ASSERT_EQUAL(count, 1U);
    ASSERT_OK(BloodInventoryDetectLowStock(&c, 5U, boost_inventory_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  BloodInventoryDetectLowStock(&c, 5U, boost_inventory_fail, NULL));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  BloodInventoryTraverse(&c, boost_inventory_fail, NULL));

    ASSERT_OK(BloodInventoryRemoveExpired(&c, &(BmsDate_t){2026U, 8U, 1U}, &count));
    CU_ASSERT_EQUAL(count, 1U);

    ASSERT_OK(BloodInventorySave(&c));
    BloodInventoryDeinitialize(&c);

    ASSERT_OK(BloodInventoryInitialize(&loaded));
    ASSERT_OK(BloodInventoryLoad(&loaded));
    ASSERT_OK(BloodInventorySearchById(&loaded, 902U, &out));
    CU_ASSERT_FALSE(out.isAvailable);
    BloodInventoryDeinitialize(&loaded);
}

static void test_boost_donation(void)
{
    BmsDonationContext_t c;
    BmsDonationContext_t loaded;
    BmsDonorContext_t donors;
    BmsInventoryContext_t inventory;
    BmsDonation_t d = boost_donation(1001U, 1U);
    BmsDonation_t out;
    uint32_t count = 0U;

    (void)remove(BMS_DONATIONS_FILE);
    ASSERT_OK(DonationManagementInitialize(&c));
    ASSERT_OK(DonationManagementLoad(&c));
    ASSERT_OK(DonorManagementInitialize(&donors));
    ASSERT_OK(BloodInventoryInitialize(&inventory));

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationManagementRecord(NULL, &donors, &inventory, &d));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationManagementRecord(&c, &donors, NULL, &d));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationManagementRecord(&c, &donors, &inventory, NULL));

    ASSERT_OK(DonationManagementSave(&c));
    ASSERT_OK(DonationManagementLoad(&c));
    ASSERT_OK(DonationManagementRecord(&c, &donors, &inventory, &d));
    ASSERT_OK(DonationManagementSearchById(&c, d.donationId, &out));
    ASSERT_STATUS(BMS_STATUS_ALREADY_EXISTS,
                  DonationManagementRecord(&c, &donors, &inventory, &d));
    ASSERT_OK(DonationManagementSave(&c));
    ASSERT_OK(DonationManagementFindByDonor(&c, d.donorId,
                                            boost_donation_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  DonationManagementFindByDonor(&c, d.donorId,
                                               boost_donation_fail, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationManagementFindByDonor(NULL, 1U,
                                               boost_donation_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationManagementFindByDonor(&c, 1U, NULL, &count));
    ASSERT_OK(DonationManagementTraverse(&c, boost_donation_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  DonationManagementTraverse(&c, boost_donation_fail, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationManagementTraverse(NULL, boost_donation_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationManagementTraverse(&c, NULL, &count));

    DonationManagementDeinitialize(&c);
    ASSERT_OK(DonationManagementInitialize(&loaded));
    ASSERT_OK(DonationManagementLoad(&loaded));
    ASSERT_OK(DonationManagementSearchById(&loaded, d.donationId, &out));
    DonationManagementDeinitialize(&loaded);

    BloodInventoryDeinitialize(&inventory);
    DonorManagementDeinitialize(&donors);
}

static void test_boost_requests(void)
{
    BmsBloodRequestContext_t c;
    BmsInventoryContext_t inventory;
    BmsBloodRequest_t low = boost_request(1101U, BMS_PRIORITY_NORMAL, 2U);
    BmsBloodRequest_t high = boost_request(1102U, BMS_PRIORITY_HIGH, 2U);
    BmsBloodRequest_t out;
    BmsBloodInventory_t stock = boost_stock(1101U, BMS_BLOOD_GROUP_A_POSITIVE, 5U,
                                            (BmsDate_t){2027U, 1U, 1U});
    uint32_t count = 0U;

    (void)remove(BMS_REQUESTS_FILE);
    ASSERT_OK(BloodRequestManagementInitialize(&c));
    ASSERT_OK(BloodRequestManagementLoad(&c));
    ASSERT_OK(BloodInventoryInitialize(&inventory));

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementCreate(NULL, &low));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementCreate(&c, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementSearchById(NULL, 1U, &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementSearchById(&c, 1U, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementApprove(NULL, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementReject(NULL, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementFulfill(NULL, &inventory, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementFulfill(&c, NULL, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementProcessNext(NULL, &inventory, &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementProcessNext(&c, NULL, &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementProcessNext(&c, &inventory, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementTraverse(NULL, boost_request_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BloodRequestManagementTraverse(&c, NULL, &count));

    ASSERT_OK(BloodRequestManagementSave(&c));
    ASSERT_OK(BloodRequestManagementLoad(&c));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND, BloodRequestManagementApprove(&c, 9999U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND, BloodRequestManagementReject(&c, 9999U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  BloodRequestManagementFulfill(&c, &inventory, 9999U));
    ASSERT_STATUS(BMS_STATUS_QUEUE_EMPTY,
                  BloodRequestManagementProcessNext(&c, &inventory, &out));

    ASSERT_OK(BloodRequestManagementCreate(&c, &low));
    ASSERT_STATUS(BMS_STATUS_ALREADY_EXISTS,
                  BloodRequestManagementCreate(&c, &low));
    ASSERT_OK(BloodRequestManagementCreate(&c, &high));
    ASSERT_OK(BloodRequestManagementTraverse(&c, boost_request_visitor, &count));

    /* Highest priority request is selected first, but insufficient stock returns it to pending. */
    ASSERT_OK(BloodInventoryAddStock(&inventory, &stock));
    ASSERT_OK(BloodRequestManagementProcessNext(&c, &inventory, &out));
    CU_ASSERT_EQUAL(out.requestId, 1102U);
    CU_ASSERT_EQUAL(out.status, BMS_REQUEST_STATUS_FULFILLED);

    ASSERT_OK(BloodRequestManagementReject(&c, 1101U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  BloodRequestManagementSearchById(&c, 9999U, &out));

    /* Exercise the insufficient-stock rollback path with a new pending request. */
    {
        BmsBloodRequest_t need = boost_request(1103U, BMS_PRIORITY_EMERGENCY, 99U);
        ASSERT_OK(BloodRequestManagementCreate(&c, &need));
        ASSERT_STATUS(BMS_STATUS_INSUFFICIENT_STOCK,
                      BloodRequestManagementProcessNext(&c, &inventory, &out));
        CU_ASSERT_EQUAL(out.status, BMS_REQUEST_STATUS_PENDING);
    }

    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  BloodRequestManagementTraverse(&c, boost_request_fail, NULL));

    ASSERT_OK(BloodRequestManagementSave(&c));
    BloodRequestManagementDeinitialize(&c);
    BloodInventoryDeinitialize(&inventory);
}

static void test_boost_notification(void)
{
    BmsNotificationContext_t c;
    BmsNotificationContext_t loaded;
    BmsNotification_t n = boost_notification(1201U);
    BmsNotification_t out;
    uint32_t sent = 0U;
    uint32_t processed = 0U;

    (void)remove(BMS_NOTIFICATIONS_FILE);
    ASSERT_OK(NotificationManagementInitialize(&c));
    ASSERT_OK(NotificationManagementLoad(&c));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementEnqueue(NULL, &n));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementEnqueue(&c, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementPeek(NULL, &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementPeek(&c, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementProcessNext(NULL, boost_notification_sender, &sent));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementProcessNext(&c, NULL, &sent));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementProcessAll(NULL, boost_notification_sender,
                                                   &sent, &processed));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementProcessAll(&c, NULL, &sent, &processed));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementProcessAll(&c, boost_notification_sender,
                                                   &sent, NULL));

    ASSERT_OK(NotificationManagementSave(&c));
    ASSERT_OK(NotificationManagementLoad(&c));
    ASSERT_STATUS(BMS_STATUS_QUEUE_EMPTY,
                  NotificationManagementProcessNext(&c, boost_notification_sender, &sent));

    ASSERT_OK(NotificationManagementEnqueue(&c, &n));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  NotificationManagementProcessNext(&c, boost_notification_fail, NULL));
    ASSERT_OK(NotificationManagementProcessNext(&c, boost_notification_sender, &sent));

    n.notificationId = 1202U;
    ASSERT_OK(NotificationManagementEnqueue(&c, &n));
    ASSERT_OK(NotificationManagementProcessAll(&c, boost_notification_sender,
                                               &sent, &processed));
    CU_ASSERT_EQUAL(processed, 1U);
    ASSERT_OK(NotificationManagementProcessAll(&c, boost_notification_sender,
                                               &sent, &processed));
    CU_ASSERT_EQUAL(processed, 0U);

    ASSERT_OK(NotificationManagementSendConsole(&n, NULL));
    ASSERT_OK(NotificationManagementSendEmailPlaceholder(&n, NULL));
    ASSERT_OK(NotificationManagementSendSmsPlaceholder(&n, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementSendConsole(NULL, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementSendEmailPlaceholder(NULL, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  NotificationManagementSendSmsPlaceholder(NULL, NULL));

    ASSERT_OK(NotificationManagementSave(&c));
    NotificationManagementDeinitialize(&c);
    ASSERT_OK(NotificationManagementInitialize(&loaded));
    ASSERT_OK(NotificationManagementLoad(&loaded));
    ASSERT_STATUS(BMS_STATUS_QUEUE_EMPTY,
                  NotificationManagementPeek(&loaded, &out));
    NotificationManagementDeinitialize(&loaded);
}

static void test_boost_emergency(void)
{
    BmsEmergencyAlertContext_t c;
    BmsEmergencyAlertContext_t loaded;
    BmsEmergencyAlert_t a = boost_alert(1301U, 77U);
    BmsEmergencyAlert_t independent = boost_alert(1302U, 0U);
    BmsEmergencyAlert_t out;

    (void)remove(BMS_EMERGENCY_ALERTS_FILE);
    ASSERT_OK(EmergencyAlertManagementInitialize(&c));
    ASSERT_OK(EmergencyAlertManagementLoad(&c));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  EmergencyAlertManagementCreate(NULL, &a));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  EmergencyAlertManagementCreate(&c, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  EmergencyAlertManagementProcessNext(NULL, &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  EmergencyAlertManagementProcessNext(&c, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  EmergencyAlertManagementResolve(NULL, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  EmergencyAlertManagementResolveByRequestId(NULL, 77U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  EmergencyAlertManagementResolveByRequestId(&c, 0U));
    CU_ASSERT_FALSE(EmergencyAlertManagementHasActiveForRequest(NULL, 77U));
    CU_ASSERT_FALSE(EmergencyAlertManagementHasActiveForRequest(&c, 0U));

    ASSERT_OK(EmergencyAlertManagementSave(&c));
    ASSERT_OK(EmergencyAlertManagementLoad(&c));
    ASSERT_STATUS(BMS_STATUS_QUEUE_EMPTY,
                  EmergencyAlertManagementProcessNext(&c, &out));

    ASSERT_OK(EmergencyAlertManagementCreate(&c, &a));
    ASSERT_OK(EmergencyAlertManagementCreate(&c, &independent));
    CU_ASSERT_TRUE(EmergencyAlertManagementHasActiveForRequest(&c, 77U));
    CU_ASSERT_FALSE(EmergencyAlertManagementHasActiveForRequest(&c, 999U));

    ASSERT_OK(EmergencyAlertManagementProcessNext(&c, &out));
    CU_ASSERT_EQUAL(out.alertId, 1301U);

    ASSERT_OK(EmergencyAlertManagementResolve(&c, 1301U));
    CU_ASSERT_FALSE(EmergencyAlertManagementHasActiveForRequest(&c, 77U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  EmergencyAlertManagementResolve(&c, 9999U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  EmergencyAlertManagementResolveByRequestId(&c, 999U));

    a.alertId = 1303U;
    a.requestId = 88U;
    ASSERT_OK(EmergencyAlertManagementCreate(&c, &a));
    ASSERT_OK(EmergencyAlertManagementResolveByRequestId(&c, 88U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  EmergencyAlertManagementResolveByRequestId(&c, 88U));

    ASSERT_OK(EmergencyAlertManagementSave(&c));
    EmergencyAlertManagementDeinitialize(&c);
    ASSERT_OK(EmergencyAlertManagementInitialize(&loaded));
    ASSERT_OK(EmergencyAlertManagementLoad(&loaded));
    CU_ASSERT_TRUE(EmergencyAlertManagementHasActiveForRequest(&loaded, 0U) == false);
    EmergencyAlertManagementDeinitialize(&loaded);
}

static void test_boost_authentication(void)
{
    BmsAuthenticationContext_t c;
    BmsAuthenticationContext_t loaded;
    BmsUser_t u;
    BmsUser_t out;
    BmsUser_t pending;
    BmsUser_t locked;
    BmsUserId_t next = 0U;

    (void)remove(BMS_USERS_FILE);
    (void)memset(&u, 0, sizeof(u));
    u.userId = 1401U;
    (void)snprintf(u.username, sizeof(u.username), "coverage_admin");
    u.role = BMS_ROLE_ADMIN;
    u.status = BMS_USER_STATUS_ACTIVE;
    u.isActive = true;

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationInitialize(NULL));
    ASSERT_OK(AuthenticationInitialize(&c));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationRegisterUser(NULL, &u, "Strong@123"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationRegisterUser(&c, NULL, "Strong@123"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationRegisterUser(&c, &u, NULL));

    ASSERT_STATUS(BMS_STATUS_PASSWORD_POLICY_FAILED,
                  AuthenticationRegisterUser(&c, &u, "weak"));
    ASSERT_OK(AuthenticationRegisterUser(&c, &u, "Strong@123"));
    CU_ASSERT_TRUE(AuthenticationAdministratorExists(&c));

    ASSERT_STATUS(BMS_STATUS_AUTHENTICATION_FAILED,
                  AuthenticationLogin(&c, "missing_user", "Strong@123", &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationLogin(&c, NULL, "Strong@123", &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationLogin(&c, "coverage_admin", NULL, &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationLogin(&c, "coverage_admin", "Strong@123", NULL));

    ASSERT_STATUS(BMS_STATUS_AUTHENTICATION_FAILED,
                  AuthenticationLogin(&c, "coverage_admin", "Wrong@123", &out));
    ASSERT_STATUS(BMS_STATUS_AUTHENTICATION_FAILED,
                  AuthenticationLogin(&c, "coverage_admin", "Wrong@123", &out));
    ASSERT_STATUS(BMS_STATUS_AUTHENTICATION_FAILED,
                  AuthenticationLogin(&c, "coverage_admin", "Wrong@123", &out));
    ASSERT_STATUS(BMS_STATUS_ACCOUNT_LOCKED,
                  AuthenticationLogin(&c, "coverage_admin", "Wrong@123", &out));

    ASSERT_OK(AuthenticationUnlockUser(&c, u.userId));
    ASSERT_OK(AuthenticationSetUserActive(&c, u.userId, false));
    ASSERT_STATUS(BMS_STATUS_ACCESS_DENIED,
                  AuthenticationLogin(&c, "coverage_admin", "Strong@123", &out));
    ASSERT_OK(AuthenticationSetUserActive(&c, u.userId, true));

    ASSERT_OK(AuthenticationSetUserStatus(&c, u.userId, BMS_USER_STATUS_LOCKED));
    ASSERT_STATUS(BMS_STATUS_ACCESS_DENIED,
                  AuthenticationLogin(&c, "coverage_admin", "Strong@123", &out));
    ASSERT_OK(AuthenticationUnlockUser(&c, u.userId));

    ASSERT_STATUS(BMS_STATUS_PASSWORD_POLICY_FAILED,
                  AuthenticationChangePassword(&c, u.userId,
                                               "Strong@123", "weak"));
    ASSERT_STATUS(BMS_STATUS_AUTHENTICATION_FAILED,
                  AuthenticationChangePassword(&c, u.userId,
                                               "Wrong@123", "NewStrong@1"));
    ASSERT_OK(AuthenticationChangePassword(&c, u.userId,
                                           "Strong@123", "NewStrong@1"));

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationSetRecoveryCode(&c, u.userId, "short"));
    ASSERT_OK(AuthenticationSetRecoveryCode(&c, u.userId, "Recover@123"));
    ASSERT_STATUS(BMS_STATUS_AUTHENTICATION_FAILED,
                  AuthenticationResetPassword(&c, "coverage_admin",
                                              "Wrong@123", "ResetStrong@1"));
    ASSERT_OK(AuthenticationResetPassword(&c, "coverage_admin",
                                          "Recover@123", "ResetStrong@1"));

    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  AuthenticationSetHospitalId(&c, 9999U, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationSetHospitalId(NULL, u.userId, 1U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationSetHospitalId(&c, u.userId, 0U));
    ASSERT_OK(AuthenticationSetHospitalId(&c, u.userId, 55U));

    ASSERT_OK(AuthenticationFindUserById(&c, u.userId, &out));
    ASSERT_OK(AuthenticationFindUserByUsername(&c, u.username, &out));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  AuthenticationFindUserById(&c, 9999U, &out));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  AuthenticationFindUserByUsername(&c, "missing_user", &out));

    ASSERT_OK(AuthenticationGetNextUserId(&c, &next));
    CU_ASSERT_TRUE(next > 1401U);
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationGetNextUserId(&c, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationFindUserById(NULL, 1U, &out));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  AuthenticationFindUserByUsername(NULL, "x", &out));

    CU_ASSERT_TRUE(AuthenticationHasRole(&u, BMS_ROLE_ADMIN));
    u.isActive = false;
    CU_ASSERT_FALSE(AuthenticationHasRole(&u, BMS_ROLE_ADMIN));
    CU_ASSERT_FALSE(AuthenticationHasRole(NULL, BMS_ROLE_ADMIN));
    CU_ASSERT_FALSE(AuthenticationAdministratorExists(NULL));

    (void)memset(&pending, 0, sizeof(pending));
    pending.userId = 1402U;
    (void)snprintf(pending.username, sizeof(pending.username), "pending_user");
    pending.role = BMS_ROLE_DONOR;
    pending.status = BMS_USER_STATUS_PENDING;
    ASSERT_OK(AuthenticationRegisterUser(&c, &pending, "Strong@123"));
    ASSERT_STATUS(BMS_STATUS_ACCESS_DENIED,
                  AuthenticationLogin(&c, "pending_user", "Strong@123", &out));

    ASSERT_OK(AuthenticationSave(&c));
    AuthenticationDeinitialize(&c);

    ASSERT_OK(AuthenticationInitialize(&loaded));
    ASSERT_OK(AuthenticationLoad(&loaded));
    ASSERT_OK(AuthenticationFindUserByUsername(&loaded, "coverage_admin", &out));
    AuthenticationDeinitialize(&loaded);

    (void)memset(&locked, 0, sizeof(locked));
    locked.userId = 1403U;
    locked.role = BMS_ROLE_ADMIN;
    locked.status = BMS_USER_STATUS_ACTIVE;
    locked.isActive = true;
}

static void test_boost_logging(void)
{
    char message[300];
    size_t i;

    remove(BMS_LOG_FILE_PATH);
    ASSERT_STATUS(BMS_STATUS_NOT_INITIALIZED, LoggingFlush());
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  LoggingWrite((BmsLogLevel_t)99, "M", "F", "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  LoggingWrite(BMS_LOG_LEVEL_INFO, NULL, "F", "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  LoggingWrite(BMS_LOG_LEVEL_INFO, "M", NULL, "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  LoggingWrite(BMS_LOG_LEVEL_INFO, "M", "F", NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  LoggingWriteFormat(BMS_LOG_LEVEL_INFO, NULL, "F", "%s", "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  LoggingWriteFormat(BMS_LOG_LEVEL_INFO, "M", NULL, "%s", "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  LoggingWriteFormat(BMS_LOG_LEVEL_INFO, "M", "F", NULL));

    ASSERT_OK(LoggingInitialize());
    ASSERT_OK(LoggingInitialize());
    ASSERT_OK(LoggingWrite(BMS_LOG_LEVEL_DEBUG, "BOOST", "test", "debug"));
    ASSERT_OK(LoggingWrite(BMS_LOG_LEVEL_INFO, "BOOST", "test", "info"));
    ASSERT_OK(LoggingWrite(BMS_LOG_LEVEL_WARNING, "BOOST", "test", "warning"));
    ASSERT_OK(LoggingWrite(BMS_LOG_LEVEL_ERROR, "BOOST", "test", "error"));
    ASSERT_OK(LoggingWriteFormat(BMS_LOG_LEVEL_INFO, "BOOST", "test",
                                 "formatted %u", 123U));
    ASSERT_OK(LoggingFlush());

    (void)memset(message, 'X', sizeof(message) - 1U);
    message[sizeof(message) - 1U] = '\0';
    for (i = 0U; i < 6000U; ++i)
    {
        ASSERT_OK(LoggingWrite(BMS_LOG_LEVEL_INFO, "BOOST", "rotation",
                               message));
    }
    LoggingDeinitialize();
    LoggingDeinitialize();

    CU_ASSERT_STRING_EQUAL(LoggingLevelToString(BMS_LOG_LEVEL_DEBUG), "DEBUG");
    CU_ASSERT_STRING_EQUAL(LoggingLevelToString(BMS_LOG_LEVEL_INFO), "INFO");
    CU_ASSERT_STRING_EQUAL(LoggingLevelToString(BMS_LOG_LEVEL_WARNING), "WARNING");
    CU_ASSERT_STRING_EQUAL(LoggingLevelToString(BMS_LOG_LEVEL_ERROR), "ERROR");
    CU_ASSERT_STRING_EQUAL(LoggingLevelToString(BMS_LOG_LEVEL_COUNT), "UNKNOWN");
}

static void test_boost_report_and_camp(void)
{
    BmsDonorContext_t d;
    BmsHospitalContext_t h;
    BmsInventoryContext_t i;
    BmsBloodRequestContext_t r;
    BmsDonationContext_t dn;
    BmsEmergencyAlertContext_t a;
    BmsDonationCampContext_t camp;
    BmsDonationCamp_t record = boost_camp(1601U);
    BmsSummaryReport_t summary;
    uint32_t count = 0U;

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementBuildSummary(NULL, &h, &i, &r, &dn, &a, &summary));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, ReportManagementPrintSummary(NULL));

    ASSERT_OK(DonorManagementInitialize(&d));
    ASSERT_OK(HospitalManagementInitialize(&h));
    ASSERT_OK(BloodInventoryInitialize(&i));
    ASSERT_OK(BloodRequestManagementInitialize(&r));
    ASSERT_OK(DonationManagementInitialize(&dn));
    ASSERT_OK(EmergencyAlertManagementInitialize(&a));
    ASSERT_OK(ReportManagementBuildSummary(&d, &h, &i, &r, &dn, &a, &summary));

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateInventoryReport(NULL, "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateInventoryReport(&i, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateDonorReport(NULL, "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateDonorReport(&d, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateHospitalReport(NULL, "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateHospitalReport(&h, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateBloodRequestReport(NULL, "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateBloodRequestReport(&r, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateDonationReport(NULL, "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateDonationReport(&dn, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateEmergencyAlertReport(NULL, "x"));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  ReportManagementGenerateEmergencyAlertReport(&a, NULL));
    ASSERT_OK(ReportManagementPrintSummary(&summary));

    (void)remove("coverage_inventory_report.txt");
    (void)remove("coverage_donor_report.txt");
    (void)remove("coverage_hospital_report.txt");
    (void)remove("coverage_request_report.txt");
    (void)remove("coverage_donation_report.txt");
    (void)remove("coverage_alert_report.txt");

    ASSERT_OK(ReportManagementGenerateInventoryReport(&i, "coverage_inventory_report.txt"));
    ASSERT_OK(ReportManagementGenerateDonorReport(&d, "coverage_donor_report.txt"));
    ASSERT_OK(ReportManagementGenerateHospitalReport(&h, "coverage_hospital_report.txt"));
    ASSERT_OK(ReportManagementGenerateBloodRequestReport(&r, "coverage_request_report.txt"));
    ASSERT_OK(ReportManagementGenerateDonationReport(&dn, "coverage_donation_report.txt"));
    ASSERT_OK(ReportManagementGenerateEmergencyAlertReport(&a, "coverage_alert_report.txt"));

    ASSERT_OK(DonationCampManagementInitialize(&camp));
    ASSERT_OK(DonationCampManagementLoad(&camp));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationCampManagementAdd(NULL, &record));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationCampManagementAdd(&camp, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationCampManagementTraverse(NULL, boost_camp_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  DonationCampManagementTraverse(&camp, NULL, &count));
    ASSERT_OK(DonationCampManagementSave(&camp));
    ASSERT_OK(DonationCampManagementLoad(&camp));
    ASSERT_OK(DonationCampManagementAdd(&camp, &record));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  DonationCampManagementTraverse(&camp, boost_camp_fail, NULL));
    ASSERT_OK(DonationCampManagementTraverse(&camp, boost_camp_visitor, &count));
    ASSERT_OK(DonationCampManagementSave(&camp));
    DonationCampManagementDeinitialize(&camp);

    (void)remove("coverage_inventory_report.txt");
    (void)remove("coverage_donor_report.txt");
    (void)remove("coverage_hospital_report.txt");
    (void)remove("coverage_request_report.txt");
    (void)remove("coverage_donation_report.txt");
    (void)remove("coverage_alert_report.txt");

    EmergencyAlertManagementDeinitialize(&a);
    DonationManagementDeinitialize(&dn);
    BloodRequestManagementDeinitialize(&r);
    BloodInventoryDeinitialize(&i);
    HospitalManagementDeinitialize(&h);
    DonorManagementDeinitialize(&d);
}

static void test_boost_graph(void)
{
    BmsHospitalGraph_t g;
    BmsHospital_t h1 = boost_hospital(1701U, "G1");
    BmsHospital_t h2 = boost_hospital(1702U, "G2");
    BmsHospital_t h3 = boost_hospital(1703U, "G3");
    BmsHospitalId_t nearest = 0U;
    uint32_t distance = 0U;
    uint32_t count = 0U;

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphInitialize(NULL));
    ASSERT_OK(GraphInitialize(&g));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphAddHospital(NULL, &h1));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphAddHospital(&g, NULL));
    ASSERT_OK(GraphAddHospital(&g, &h1));
    ASSERT_STATUS(BMS_STATUS_ALREADY_EXISTS, GraphAddHospital(&g, &h1));
    ASSERT_OK(GraphAddHospital(&g, &h2));
    ASSERT_OK(GraphAddHospital(&g, &h3));

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphAddRoute(NULL, 1U, 2U, 5U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphAddRoute(&g, 1U, 2U, 0U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND, GraphAddRoute(&g, 1U, 999U, 5U));
    ASSERT_OK(GraphAddRoute(&g, 1701U, 1702U, 10U));
    ASSERT_OK(GraphAddRoute(&g, 1701U, 1703U, 5U));

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphGetRouteDistance(NULL, 1U, 2U, &distance));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphGetRouteDistance(&g, 1U, 2U, NULL));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND, GraphGetRouteDistance(&g, 1701U, 999U, &distance));
    ASSERT_OK(GraphGetRouteDistance(&g, 1701U, 1703U, &distance));
    ASSERT_STATUS(BMS_STATUS_ROUTE_NOT_FOUND,
                  GraphGetRouteDistance(&g, 1702U, 1703U, &distance));

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphFindNearestHospital(NULL, 1U, &nearest, &distance));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphFindNearestHospital(&g, 1U, NULL, &distance));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphFindNearestHospital(&g, 1U, &nearest, NULL));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND, GraphFindNearestHospital(&g, 999U, &nearest, &distance));
    ASSERT_OK(GraphFindNearestHospital(&g, 1701U, &nearest, &distance));
    CU_ASSERT_EQUAL(nearest, 1703U);
    CU_ASSERT_EQUAL(distance, 5U);

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  GraphBreadthFirstSearch(NULL, 1U, boost_request_graph_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  GraphDepthFirstSearch(&g, 1701U, NULL, &count));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  GraphBreadthFirstSearch(&g, 999U, boost_request_graph_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  GraphDepthFirstSearch(&g, 1701U, boost_graph_fail, NULL));
    count = 0U;
    ASSERT_OK(GraphBreadthFirstSearch(&g, 1701U, boost_request_graph_visitor, &count));
    CU_ASSERT_EQUAL(count, 3U);

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  GraphBroadcastEmergencyAlert(NULL, 1U, 10U,
                                               boost_request_graph_visitor, &count));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  GraphBroadcastEmergencyAlert(&g, 1701U, 10U, NULL, &count));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  GraphBroadcastEmergencyAlert(&g, 999U, 10U,
                                               boost_request_graph_visitor, &count));
    count = 0U;
    ASSERT_OK(GraphBroadcastEmergencyAlert(&g, 1701U, 6U,
                                           boost_request_graph_visitor, &count));
    CU_ASSERT_EQUAL(count, 1U);
    ASSERT_STATUS(BMS_STATUS_INTERNAL_ERROR,
                  GraphBroadcastEmergencyAlert(&g, 1701U, 20U,
                                               boost_graph_fail, NULL));

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphRemoveRoute(NULL, 1U, 2U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND, GraphRemoveRoute(&g, 1701U, 999U));
    ASSERT_OK(GraphRemoveRoute(&g, 1701U, 1702U));
    ASSERT_STATUS(BMS_STATUS_ROUTE_NOT_FOUND,
                  GraphGetRouteDistance(&g, 1701U, 1702U, &distance));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, GraphRemoveHospital(NULL, 1U));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND, GraphRemoveHospital(&g, 999U));
    ASSERT_OK(GraphRemoveHospital(&g, 1702U));
    GraphClear(&g);
    GraphClear(NULL);
}


static void test_boost_multithreading(void)
{
    BmsInventoryContext_t inventory;
    BmsThreadController_t controller;

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BmsThreadControllerStart(NULL, &inventory, 1U, 5U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BmsThreadControllerStart(&controller, NULL, 1U, 5U));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  BmsThreadControllerStart(&controller, &inventory, 0U, 5U));

    ASSERT_OK(BloodInventoryInitialize(&inventory));
    {
        BmsBloodInventory_t expired =
            boost_stock(1501U, BMS_BLOOD_GROUP_O_NEGATIVE, 2U,
                        (BmsDate_t){2020U, 1U, 1U});
        ASSERT_OK(BloodInventoryAddStock(&inventory, &expired));
    }
    ASSERT_OK(BmsThreadControllerStart(&controller, &inventory, 1U, 5U));
    {
        struct timespec delay = {1, 200000000L};
        (void)nanosleep(&delay, NULL);
    }
    BmsThreadControllerStop(&controller);
    BmsThreadControllerStop(NULL);
    BloodInventoryDeinitialize(&inventory);
}

static void test_boost_low_level_structures(void)
{
    BmsQueue_t q;
    BmsHashTable_t table;
    BmsLinkedList_t list;
    int a = 1;
    int b = 2;
    int out = 0;
    void *found = NULL;

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, QueueInitialize(NULL, 2U, sizeof(int)));
    ASSERT_OK(QueueInitialize(&q, 1U, sizeof(int)));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, QueueEnqueue(NULL, &a));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, QueueEnqueue(&q, NULL));
    ASSERT_OK(QueueEnqueue(&q, &a));
    ASSERT_STATUS(BMS_STATUS_QUEUE_FULL, QueueEnqueue(&q, &b));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, QueuePeek(&q, NULL));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT, QueueDequeue(&q, NULL));
    ASSERT_OK(QueuePeek(&q, &out));
    ASSERT_OK(QueueDequeue(&q, &out));
    ASSERT_STATUS(BMS_STATUS_QUEUE_EMPTY, QueuePeek(&q, &out));
    ASSERT_STATUS(BMS_STATUS_QUEUE_EMPTY, QueueDequeue(&q, &out));
    CU_ASSERT_EQUAL(QueueGetCount(&q), 0U);
    QueueClear(&q);
    QueueDeinitialize(&q);

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  HashTableInitialize(NULL, 3U, sizeof(int), BMS_HASH_KEY_UINT32));
    ASSERT_OK(HashTableInitialize(&table, 3U, sizeof(int), BMS_HASH_KEY_UINT32));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  HashTableInsertUint32(NULL, 1U, &a));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  HashTableInsertUint32(&table, 1U, NULL));
    ASSERT_OK(HashTableInsertUint32(&table, 1U, &a));
    ASSERT_STATUS(BMS_STATUS_ALREADY_EXISTS,
                  HashTableInsertUint32(&table, 1U, &a));
    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  HashTableSearchUint32(&table, 1U, NULL));
    ASSERT_OK(HashTableSearchUint32(&table, 1U, &found));
    ASSERT_STATUS(BMS_STATUS_NOT_FOUND,
                  HashTableDeleteUint32(&table, 1U + 100U));
    HashTableClear(&table);
    HashTableDeinitialize(&table);

    ASSERT_STATUS(BMS_STATUS_INVALID_ARGUMENT,
                  LinkedListInitialize(NULL, sizeof(int)));
    ASSERT_OK(LinkedListInitialize(&list, sizeof(int)));
    ASSERT_STATUS(BMS_STATUS_MEMORY_ERROR, LinkedListInsertFront(NULL, &a));
    ASSERT_STATUS(BMS_STATUS_MEMORY_ERROR, LinkedListInsertBack(&list, NULL));
    ASSERT_OK(LinkedListInsertFront(&list, &a));
    ASSERT_OK(LinkedListInsertBack(&list, &b));
    LinkedListClear(&list);
    LinkedListClear(&list);
}

void RegisterCoverageBoostTests(void)
{
    CU_pSuite suite = CU_add_suite("Coverage Boost", NULL, NULL);
    if (suite == NULL)
    {
        return;
    }

    (void)CU_add_test(suite, "utility and validation edge paths",
                      test_boost_utility);
    (void)CU_add_test(suite, "file persistence and corruption",
                      test_boost_file_management);
    (void)CU_add_test(suite, "donor persistence and errors",
                      test_boost_donor);
    (void)CU_add_test(suite, "hospital persistence and errors",
                      test_boost_hospital);
    (void)CU_add_test(suite, "inventory persistence and errors",
                      test_boost_inventory);
    (void)CU_add_test(suite, "donation persistence and visitors",
                      test_boost_donation);
    (void)CU_add_test(suite, "request priority and processing",
                      test_boost_requests);
    (void)CU_add_test(suite, "notification error and persistence paths",
                      test_boost_notification);
    (void)CU_add_test(suite, "emergency alert resolution paths",
                      test_boost_emergency);
    (void)CU_add_test(suite, "authentication security paths",
                      test_boost_authentication);
    (void)CU_add_test(suite, "logging validation and rotation",
                      test_boost_logging);
    (void)CU_add_test(suite, "reports and donation camps",
                      test_boost_report_and_camp);
    (void)CU_add_test(suite, "graph error and traversal paths",
                      test_boost_graph);
    (void)CU_add_test(suite, "queue hash and linked-list edge paths",
                      test_boost_low_level_structures);
    (void)CU_add_test(suite, "multithreading start and stop",
                      test_boost_multithreading);
}
