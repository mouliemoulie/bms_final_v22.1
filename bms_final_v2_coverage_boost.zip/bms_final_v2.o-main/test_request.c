
#include "test_common.h"
#include "blood_request_management.h"

static BmsBloodRequest_t req(uint32_t id,BmsPriority_t p)
{
    BmsBloodRequest_t r;
    memset(&r,0,sizeof r);
    r.requestId=id; r.requesterHospitalId=1; r.requesterId=1;
    r.bloodGroup=BMS_BLOOD_GROUP_A_POSITIVE; r.requestedUnits=2;
    r.priority=p; r.status=BMS_REQUEST_STATUS_PENDING;
    r.requestDate=(BmsDate_t){2026,8,4};
    return r;
}

static void test_create_approve_reject(void)
{
    BmsBloodRequestContext_t c;
    BmsBloodRequest_t a=req(1,BMS_PRIORITY_NORMAL),b=req(2,BMS_PRIORITY_HIGH),out;

    ASSERT_OK(BloodRequestManagementInitialize(&c));
    ASSERT_OK(BloodRequestManagementCreate(&c,&a));
    ASSERT_STATUS(BMS_STATUS_ALREADY_EXISTS,BloodRequestManagementCreate(&c,&a));
    ASSERT_OK(BloodRequestManagementCreate(&c,&b));
    ASSERT_OK(BloodRequestManagementSearchById(&c,1,&out));
    ASSERT_OK(BloodRequestManagementApprove(&c,1));
    ASSERT_OK(BloodRequestManagementReject(&c,2));
    BloodRequestManagementDeinitialize(&c);
}

static void test_process_and_fulfill(void)
{
    BmsBloodRequestContext_t c; BmsInventoryContext_t inv;
    BmsBloodRequest_t a=req(1,BMS_PRIORITY_EMERGENCY),out;
    BmsBloodInventory_t stock={1,BMS_BLOOD_GROUP_A_POSITIVE,5,{2026,1,1},{2027,1,1},true};

    ASSERT_OK(BloodRequestManagementInitialize(&c));
    ASSERT_OK(BloodInventoryInitialize(&inv));
    ASSERT_OK(BloodInventoryAddStock(&inv,&stock));
    ASSERT_OK(BloodRequestManagementCreate(&c,&a));
    ASSERT_OK(BloodRequestManagementApprove(&c,1));
    ASSERT_OK(BloodRequestManagementFulfill(&c,&inv,1));
    ASSERT_OK(BloodRequestManagementSearchById(&c,1,&out));
    CU_ASSERT_EQUAL(out.status,BMS_REQUEST_STATUS_FULFILLED);
    CU_ASSERT_EQUAL(out.fulfilledUnits,2U);

    BloodInventoryDeinitialize(&inv);
    BloodRequestManagementDeinitialize(&c);
}

static void test_request_missing_and_insufficient(void)
{
    BmsBloodRequestContext_t c; BmsInventoryContext_t inv;
    BmsBloodRequest_t a=req(7,BMS_PRIORITY_HIGH),out;

    ASSERT_OK(BloodRequestManagementInitialize(&c));
    ASSERT_OK(BloodInventoryInitialize(&inv));

    CU_ASSERT_NOT_EQUAL(BloodRequestManagementSearchById(&c,999U,&out),BMS_STATUS_OK);

    ASSERT_OK(BloodRequestManagementCreate(&c,&a));
    ASSERT_OK(BloodRequestManagementApprove(&c,7));
    CU_ASSERT_NOT_EQUAL(BloodRequestManagementFulfill(&c,&inv,7),BMS_STATUS_OK);

    BloodInventoryDeinitialize(&inv);
    BloodRequestManagementDeinitialize(&c);
}

void RegisterRequestTests(void)
{
    CU_pSuite s=CU_add_suite("Blood Request",NULL,NULL);
    CU_add_test(s,"create duplicate approve reject",test_create_approve_reject);
    CU_add_test(s,"fulfill with inventory",test_process_and_fulfill);
    CU_add_test(s,"missing and insufficient cases",test_request_missing_and_insufficient);
}
