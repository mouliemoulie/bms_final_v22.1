#!/bin/sh
set -eu

COVERAGE_DIR="analysis/coverage"
REPORT="coverage_summary.txt"
EXECUTABLE="cunit_coverage"

echo "======================================"
echo "       BMS GCOV CODE COVERAGE"
echo "======================================"

command -v gcc >/dev/null 2>&1 || {
    echo "ERROR: gcc is not installed or not in PATH."
    exit 1
}
command -v gcov >/dev/null 2>&1 || {
    echo "ERROR: gcov is not installed or not in PATH."
    exit 1
}

rm -rf "$COVERAGE_DIR"
mkdir -p "$COVERAGE_DIR"
rm -f ./*.gcda ./*.gcno ./*.gcov "$EXECUTABLE"

UTILITY_SOURCE="utility_updated.c"
if [ ! -f "$UTILITY_SOURCE" ]; then
    UTILITY_SOURCE="utility.c"
fi

SOURCES="
authentication.c
blood_inventory.c
blood_request_management.c
common_error_codes.c
common_validation.c
config.c
donation_camp_management.c
donation_management.c
donor_management.c
emergency_alert_management.c
file_management.c
file_names.c
graph_management.c
hash_table.c
hospital_management.c
linked_list.c
logging.c
multithreading.c
notification_management.c
queue_management.c
report_management.c
$UTILITY_SOURCE
"

echo ""
echo "Building CUnit tests with GCOV instrumentation..."

gcc -std=c11 -O0 -g --coverage \
    -Wall -Wextra -Wpedantic -pthread \
    test_runner.c test_*.c \
    $SOURCES \
    -lcunit -o "$EXECUTABLE"

echo "Build successful."
echo ""
echo "Running CUnit tests..."

if "./$EXECUTABLE" > "$COVERAGE_DIR/cunit_test_output.txt" 2>&1
then
    TEST_RC=0
else
    TEST_RC=$?
fi
cat "$COVERAGE_DIR/cunit_test_output.txt"
if [ ! -f "$EXECUTABLE" ]; then
    echo "ERROR: Coverage executable was not created."
    exit 1
fi

echo ""
echo "Generating GCOV reports..."

: > "$REPORT"
echo "BMS CODE COVERAGE SUMMARY" >> "$REPORT"
echo "=========================" >> "$REPORT"
echo "" >> "$REPORT"

for SRC in $SOURCES
do
    if [ -f "$SRC" ]; then
        gcov -b -c "$SRC" >> "$REPORT" 2>&1 || true
    fi
done

for FILE in ./*.gcov
do
    if [ -f "$FILE" ]; then
        mv "$FILE" "$COVERAGE_DIR/"
    fi
done

echo "" >> "$REPORT"
echo "GCOV files: $COVERAGE_DIR" >> "$REPORT"

echo ""
echo "========================================"
echo "Coverage summary saved to:"
echo "$REPORT"
echo "========================================"
echo ""
grep -E "File '|Lines executed:|Branches executed:|Taken at least once:|Calls executed:" \
    "$REPORT" || true

echo ""
echo "Generated GCOV files:"
ls -1 "$COVERAGE_DIR"/*.gcov 2>/dev/null || true

if [ "$TEST_RC" -ne 0 ]; then
    echo ""
    echo "WARNING: One or more CUnit tests failed (exit code $TEST_RC)."
    exit "$TEST_RC"
fi
